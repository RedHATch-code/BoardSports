const STORAGE_KEY = 'boardsports:appearance'

const DEFAULT_PREFERENCES = {
  theme: 'dark',
  accent: 'orange',
  density: 'comfortable'
}

const ACCENT_VALUES = {
  orange: { color: '#d66d24', rust: '#c24b1f', soft: 'rgba(214, 109, 36, 0.16)' },
  teal: { color: '#2f9ea3', rust: '#17777c', soft: 'rgba(47, 158, 163, 0.16)' },
  sand: { color: '#b7a98a', rust: '#8f7d5b', soft: 'rgba(183, 169, 138, 0.18)' }
}

function readStoredPreferences() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY)
    return raw ? JSON.parse(raw) : {}
  } catch (error) {
    return {}
  }
}

export function getAppearancePreferences() {
  const stored = readStoredPreferences()
  return {
    ...DEFAULT_PREFERENCES,
    ...stored,
    theme: ['dark', 'light', 'system'].includes(stored.theme) ? stored.theme : DEFAULT_PREFERENCES.theme,
    accent: ACCENT_VALUES[stored.accent] ? stored.accent : DEFAULT_PREFERENCES.accent,
    density: ['comfortable', 'compact'].includes(stored.density) ? stored.density : DEFAULT_PREFERENCES.density
  }
}

export function resolveTheme(theme = getAppearancePreferences().theme) {
  if (theme !== 'system') return theme
  return window.matchMedia?.('(prefers-color-scheme: light)').matches ? 'light' : 'dark'
}

export function applyAppearancePreferences(preferences = getAppearancePreferences()) {
  const resolvedTheme = resolveTheme(preferences.theme)
  const accent = ACCENT_VALUES[preferences.accent] || ACCENT_VALUES.orange
  const root = document.documentElement

  root.dataset.theme = resolvedTheme
  root.dataset.themeChoice = preferences.theme
  root.dataset.accent = preferences.accent
  root.dataset.density = preferences.density
  root.style.colorScheme = resolvedTheme
  root.style.setProperty('--brand-orange', accent.color)
  root.style.setProperty('--brand-rust', accent.rust)
  root.style.setProperty('--accent-soft', accent.soft)
  root.style.setProperty('--rift-metal', accent.color)
  root.style.setProperty('--rift-metal-soft', accent.soft)

  window.dispatchEvent(new CustomEvent('boardsports:appearance-change', {
    detail: { ...preferences, resolvedTheme }
  }))
}

export function saveAppearancePreferences(updates) {
  const next = {
    ...getAppearancePreferences(),
    ...updates
  }

  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next))
  } catch (error) {
    console.warn('Nao foi possivel guardar preferencias visuais:', error)
  }

  applyAppearancePreferences(next)
  return next
}

export function bindSystemThemeListener() {
  const query = window.matchMedia?.('(prefers-color-scheme: light)')
  if (!query) return

  query.addEventListener?.('change', () => {
    const preferences = getAppearancePreferences()
    if (preferences.theme === 'system') applyAppearancePreferences(preferences)
  })
}

applyAppearancePreferences()
bindSystemThemeListener()
